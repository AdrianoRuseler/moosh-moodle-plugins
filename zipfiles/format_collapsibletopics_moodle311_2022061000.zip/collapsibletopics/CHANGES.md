moodle-format_collapsibletopics
============================

Changes
-------
### v3.9
* 2020-06-16 - Fix issue #19 - collapse problem with hidden sections.

### v3.8
* 2019-11-17 - Rebuild amd module with new transpiler
* 2019-11-17 - Fix wrong behaviour of section collapsing with bootstrap in moodle 3.8.

### v3.7.2
* 2019-10-09 - Transfer toggle state persistance from db to browser storage.

### v3.7.1
* 2019-08-21 - Add section progress bar feature (initiated by Chris Kenniburg)
* 2019-08-23 - Fix display of section 0 title to be consistent with core topics format (issue #1)

### v3.7
* 2019-05-20 - Remove support for legacy themes.
* 2019-08-20 - Add toggle icon for rtl languages.
* 2019-08-20 - Fix issue #12 Wrong item labels in drop targets list.