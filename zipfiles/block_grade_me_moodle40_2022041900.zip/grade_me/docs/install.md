# Installation
1. Place this plugin’s code into blocks/grade_me within your Moodle or Totara install.
2. From the Moodle Administration block, click Site Administration, then "Notifications".
3. Follow the on-screen instructions to complete the install.