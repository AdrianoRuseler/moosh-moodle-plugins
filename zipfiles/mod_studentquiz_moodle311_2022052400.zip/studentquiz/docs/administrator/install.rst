Install
=======

Download StudentQuiz from the `Moodle Plugin Directory`_ and install by going to the 'Site administration -> Plugins -> Install' plugins page.
You can try StudentQuiz without installing on the `StudentQuiz Demo Page`_.

.. _Moodle Plugin Directory: https://moodle.org/plugins/mod_studentquiz
.. _StudentQuiz Demo Page: http://studentquiz.hsr.ch