eTask topics format extends Topics format and provides the shortest way to manage activities and their comfortable grading. In
addition to its clarity, it creates a motivating and competitive environment supporting a positive educational experience.

#### Links

- [Documentation](https://drlikm.gitlab.io/format_etask/)
- [Changelog](https://drlikm.gitlab.io/format_etask/changelog/)
- [Plugin page](https://moodle.org/plugins/format_etask)
- [Discussion forum](https://moodle.org/mod/forum/discuss.php?d=415615)

#### Awards

![Automated testing support](https://moodle.org/pluginfile.php/50/local_plugins/award_icon/5/auto_test2.png?preview=thumb)
![Early bird](https://moodle.org/pluginfile.php/50/local_plugins/award_icon/8/Early%20bird%20icon.png?preview=thumb)
![Privacy friendly](https://moodle.org/pluginfile.php/50/local_plugins/award_icon/11/privacy_friendly2.png?preview=thumb)

#### Thanks to

We are using [JetBrains](https://www.jetbrains.com/?from=etasktopicsformat) to develop this plugin.
