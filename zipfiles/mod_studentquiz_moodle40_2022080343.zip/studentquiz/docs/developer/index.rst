Developer Manual
================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   design
   local
   testing
   ci
   deployment
   mobile
   special
   upgrade

Welcome to the developer manual for StudentQuiz! If you are interested
to contribute to the plugin, or want to know about the design of the plugin
you have come to the right place. We introduce you to our development setup
and present the most important design decisions
