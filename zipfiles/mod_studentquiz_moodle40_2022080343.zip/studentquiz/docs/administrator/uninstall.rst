Uninstall
=========

**Important**:
  Make sure all the questions have been backed up! One way to do this is to export them usind the moodle question bank,
  as removing or uninstalling the StudentQuiz activity also removes all questions in the same context.

To uninstall the StudentQuiz Activity follow the navigation as follows: "Site administration -> Plugins -> Plugins overview"

Look for StudentQuiz and click “Uninstall”.

If “Uninstall” is not available, it means you're using the deprecated StudentQuiz Question Behaviour plugin prior to StudentQuiz 3.0. Remove the Question Behaviour plugin by deleting the directory your_moodle_directory/question/behaviour/studentquiz.